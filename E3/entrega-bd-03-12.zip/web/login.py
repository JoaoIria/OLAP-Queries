#!/usr/bin/python3
data_base = 'ist1103557'
db_host = 'db.tecnico.ulisboa.pt'
db_port = 5432
db_password = 'aaaa1111'
db_name = data_base
credentials = "host=%s port=%d user=%s password=%s dbname=%s" % (db_host, db_port, data_base, db_password, data_base)
